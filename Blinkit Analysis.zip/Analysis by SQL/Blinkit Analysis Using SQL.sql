create database blinkitdb;
use blinkitdb;
# imported csv file as a table, named blinkit_data

select*from blinkit_data;
select count(*) from blinkit_data;

-- Data Cleaning
UPDATE blinkit_data 
SET 
    ï»¿Item_Fat_Content = CASE
        WHEN ï»¿Item_Fat_Content IN ('LF' , 'low fat') THEN 'Low Fat'
        WHEN ï»¿Item_Fat_Content = 'reg' THEN 'Regular'
        ELSE ï»¿Item_Fat_Content
    END;
select distinct(ï»¿Item_Fat_Content) from blinkitdb.blinkit_data; #now we can see there is only two values in the column
-- Finding KPI's as per business requirement
# Total Sales
# In SQL, CAST is a function used to convert one data type into another
SELECT 
    CONCAT(CAST(SUM(Sales)/1000000 AS DECIMAL(10,2)), ' M') AS Total_Sales_Millions
FROM 
    blinkitdb.blinkit_data;
# Average Sales
select cast(avg(Sales) as decimal(10,2)) as 'Average_Sales' from blinkitdb.blinkit_data;
# Number of Items
select count(*) as 'Number_of_Items' from blinkitdb.blinkit_data;
# Average Rating
select cast(avg(Rating) as decimal(10,2)) as 'avg_rating' from blinkitdb.blinkit_data;
-- Granular Requirements
# 1. Total Sales by Fat Content
SELECT 
    ï»¿Item_Fat_Content,
    CONCAT(CAST(SUM(Sales) / 1000000 AS DECIMAL (10 , 2 )),
            ' M') AS Total_Sales_Millions,
    CAST(AVG(Sales) AS DECIMAL (10 , 2 )) AS 'Average_Sales',
    COUNT(*) AS 'Number_of_Items',
    CAST(AVG(Rating) AS DECIMAL (10 , 2 )) AS 'avg_rating'
FROM
    blinkitdb.blinkit_data
GROUP BY ï»¿Item_Fat_Content
ORDER BY Total_Sales_Millions DESC;

# 2. Total Sales by Item Type:
SELECT 
    Item_Type, cast(SUM(Sales) as decimal(10,2)) AS Total_Sales,
    CAST(AVG(Sales) AS DECIMAL (10 , 2 )) AS 'Average_Sales',
    COUNT(*) AS 'Number_of_Items',
    CAST(AVG(Rating) AS DECIMAL (10 , 2 )) AS 'avg_rating'
FROM 
    blinkitdb.blinkit_data group by Item_Type order by Total_Sales desc;
# 3. Fat Content by Outlet for Total Sales:

SELECT 
    Outlet_Location_Type,
    ï»¿Item_Fat_Content,
    CAST(SUM(Sales) AS DECIMAL (10 , 2 )) AS Total_Sales,
    CAST(AVG(Sales) AS DECIMAL (10 , 2 )) AS 'Average_Sales',
    COUNT(*) AS 'Number_of_Items',
    CAST(AVG(Rating) AS DECIMAL (10 , 2 )) AS 'avg_rating'
FROM
    blinkitdb.blinkit_data
GROUP BY ï»¿Item_Fat_Content , Outlet_Location_Type
ORDER BY Outlet_Location_Type ASC;

# 4. Total Sales by Outlet Establishment:
SELECT 
    Outlet_Establishment_Year,
    CAST(SUM(Sales) AS DECIMAL (10 , 2 )) AS Total_Sales,
    CAST(AVG(Sales) AS DECIMAL (10 , 2 )) AS 'Average_Sales',
    COUNT(*) AS 'Number_of_Items',
    CAST(AVG(Rating) AS DECIMAL (10 , 2 )) AS 'avg_rating'
FROM
    blinkitdb.blinkit_data
GROUP BY Outlet_Establishment_Year
ORDER BY Total_Sales DESC;

-- Chart’s Requirements
# 5. Percentage of Sales by Outlet Size:
SELECT 
    Outlet_Size, 
    CAST(SUM(Sales) AS DECIMAL(10,2)) AS Total_Sales,
    CAST((SUM(Sales) * 100.0 / SUM(SUM(Sales)) OVER()) AS DECIMAL(10,2)) AS Sales_Percentage
FROM blinkitdb.blinkit_data
GROUP BY Outlet_Size
ORDER BY Total_Sales DESC;
# 6. Sales by Outlet Location
select Outlet_Location_Type, cast( sum(Sales) as decimal(10,2)) as Total_Sales from blinkitdb.blinkit_data group by Outlet_Location_Type;
# 7.All Metrics by Outlet Type
SELECT 
    Outlet_Type, cast(SUM(Sales) as decimal(10,2)) AS Total_Sales,
    CAST(AVG(Sales) AS DECIMAL (10 , 2 )) AS 'Average_Sales',
    COUNT(*) AS 'Number_of_Items',
    CAST(AVG(Rating) AS DECIMAL (10 , 2 )) AS 'avg_rating'
FROM 
    blinkitdb.blinkit_data group by Outlet_Type order by Total_Sales desc;
